package uk.ac.derby.ldi.sili2.interpreter;

import uk.ac.derby.ldi.sili2.interpreter.Display.Reference;
import uk.ac.derby.ldi.sili2.values.Value;

public class DisplayClass {
	

	private final int maximumClassNesting = 6;
	private ClassInvocation[] display = new ClassInvocation[maximumClassNesting];
	private int currentLevel;

	/** Reference to a slot. */
	class Reference {
		private int displayDepth;
		private int slotNumber;
		
		/** Ctor */
		Reference(int depth, int slot) {
			displayDepth = depth;
			slotNumber = slot;
		}
		
		/** Set value pointed to by this reference. */
		void setValue(Value v) {
			
			display[displayDepth].setValue(slotNumber, v);
		}
		
		/** Get value pointed to by this reference. */
		Value getValue() {
			return display[displayDepth].getValue(slotNumber);
		}
	}
	
	/** Ctor */
	DisplayClass() {
		// root or 0th scope
		
		currentLevel = 0;
		display[currentLevel] = new ClassInvocation(new ClassDefinition("%main", currentLevel));
		//System.out.print(display[0].getValue(1));
	}
	
	 /**Execute a Class in its scope, using a specified parser. */
	 Value execute(ClassInvocation fn, Parser p) {
		int changeLevel = fn.getLevel();
		ClassInvocation oldContext = display[changeLevel];
		int oldLevel = currentLevel;
		display[changeLevel] = fn;
		currentLevel = changeLevel;
		Value v = display[currentLevel].execute(p);
		display[changeLevel] = oldContext;
		currentLevel = oldLevel;
		return v;
	}
	
	/** Get the current scope nesting level. */
	int getLevel() {
		//System.out.println(display);
		return currentLevel;
	}
	
	/** Return a Reference to a variable or parameter.  Return null if it doesn't exist. */
	Reference findReference(String name) {
		int level = currentLevel;
		while (level >= 0) {
			int offset = display[level].findSlotNumber(name);
			if (offset >= 0)
				return new Reference(level, offset);
			level--;
		}
		return null;		
	}

	/** Create a variable in the current level and return its Reference. */
	Reference defineVariable(String name) {
		//System.out.println(slots)
		return new Reference(currentLevel, display[currentLevel].defineVariable(name));
	}

	/** Find a Class.  Return null if it doesn't exist. */
	ClassDefinition findClass(String name) {
		int level = currentLevel;
		while (level >= 0) {
			ClassDefinition definition = display[level].findClass(name);
			if (definition != null)
				return definition;
			level--;
		}
		return null;
	}
	Integer findIntVariable(String name) {
		int level = currentLevel;
		while(level>=0) {
			Integer definition=display[level].findVariable(name);
			if(definition != null)
				return definition;
			level--;			
		}
		return null;
	}
	
	ClassDefinition findClassLowerLevel(String name) {
		int level=currentLevel;
		ClassDefinition definition = display[level-1].findClass(name);
		if(definition !=null)
			return definition;
		return null;
	}

	/** Find a Class in the current level.  Return null if it doesn't exist. */
	ClassDefinition findClassInCurrentLevel(String name) {
		return display[currentLevel].findClass(name);
	}
	
	FunctionDefinition findFunctionInCurrentLevel(String name) {
		return display[currentLevel].findFunction(name);
	}
	
	/** Add a Class to the current level. */
	void addClass(ClassDefinition definition) {
		display[currentLevel].addClass(definition);
		
	}
	
	void addFunction(FunctionDefinition definition) {
		display[currentLevel].addFunction(definition);
	}
	
}
