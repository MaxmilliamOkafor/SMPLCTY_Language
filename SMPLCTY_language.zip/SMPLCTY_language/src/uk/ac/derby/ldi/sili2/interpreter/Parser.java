package uk.ac.derby.ldi.sili2.interpreter;

import java.util.Vector;

import uk.ac.derby.ldi.sili2.parser.ast.*;
import uk.ac.derby.ldi.sili2.values.*;

public class Parser implements SiliVisitor {
	
	// Scope display handler
	private Display scope = new Display();
	private DisplayClass scopeclass =new DisplayClass();
	private DisplayArray scopearray=new DisplayArray();
	
	// Get the ith child of a given node.
	private static SimpleNode getChild(SimpleNode node, int childIndex) {
		return (SimpleNode)node.jjtGetChild(childIndex);
	}
	
	// Get the token value of the ith child of a given node.
	private static String getTokenOfChild(SimpleNode node, int childIndex) {
		return getChild(node, childIndex).tokenValue;
	}

	
	// Execute a given child of the given node
	private Object doChild(SimpleNode node, int childIndex, Object data) {
		return node.jjtGetChild(childIndex).jjtAccept(this, data);
	}
	
	// Execute a given child of a given node, and return its value as a Value.
	// This is used by the expression evaluation nodes.
	Value doChild(SimpleNode node, int childIndex) {
		return (Value)doChild(node, childIndex, null);
	}
	
	// Execute all children of the given node
	Object doChildren(SimpleNode node, Object data) {
		//System.out.println("do children:"+data);
		return node.childrenAccept(this, data);
	}
	
	// Called if one of the following methods is missing...
	public Object visit(SimpleNode node, Object data) {
		System.out.println(node + ": acceptor not implemented in subclass?");
		return data;
	}
	
	// Execute a Sili program
	public Object visit(ASTCode node, Object data) {
		return doChildren(node, data);	
	}
	
	// Execute a statement
	public Object visit(ASTStatement node, Object data) {
		//System.out.println("statment parent:"+node.jjtGetParent());
		return doChildren(node, data);	
	}

	// Execute a block
	public Object visit(ASTBlock node, Object data) {
		return doChildren(node, data);	
	}

	// Function definition
	public Object visit(ASTFnDef node, Object data) {
		// Already defined?
		if (node.optimised != null)
			return data;
		// Child 0 - identifier (fn name)
		
		String fnname = getTokenOfChild(node, 0);
	
		if (scope.findFunctionInCurrentLevel(fnname) != null )
			throw new ExceptionSemantic("Function " + fnname + " already exists.");
		if (scopeclass.findFunctionInCurrentLevel(fnname) !=null)
			throw new ExceptionSemantic("Function " + fnname +"already exists in"+ scopeclass.getClass());
		FunctionDefinition currentFunctionDefinition = new FunctionDefinition(fnname, scope.getLevel() + 1);
		
		ClassDefinition currentClassDefinition =  (ClassDefinition)data;
		if(currentClassDefinition!=null)
			currentClassDefinition.addFunction(currentFunctionDefinition);
		
		//scopeclass.addFunction(currentFunctionDefinition);
		
		// Child 1 - function definition parameter list
		doChild(node, 1, currentFunctionDefinition);
		// Add to available functions
		scope.addFunction(currentFunctionDefinition);
		// Child 2 - function body
		currentFunctionDefinition.setFunctionBody(getChild(node, 2));
		// Child 3 - optional return expression
		if (node.fnHasReturn)
			currentFunctionDefinition.setFunctionReturnExpression(getChild(node, 3));
		// Preserve this definition for future reference, and so we don't define
		// it every time this node is processed.
		node.optimised = currentFunctionDefinition;
		return data;
	}
	
	// Function definition parameter list
	public Object visit(ASTParmlist node, Object data) {
		FunctionDefinition currentDefinition = (FunctionDefinition)data;
		for (int i=0; i<node.jjtGetNumChildren(); i++)
			currentDefinition.defineParameter(getTokenOfChild(node, i));
		return data;
	}
	
	// Function body
	public Object visit(ASTFnBody node, Object data) {
		 //System.out.println("where?: "+node);
		return doChildren(node, data);
	}
	
	// Function return expression
	public Object visit(ASTReturnExpression node, Object data) {
		return doChildren(node, data);
	}
	
	// Function call
	public Object visit(ASTCall node, Object data) {
		FunctionDefinition fndef;
		if (node.optimised == null) { 
			// Child 0 - identifier (fn name)
			String fnname = getTokenOfChild(node, 0);
			fndef = scope.findFunction(fnname);
			if (fndef == null)
				throw new ExceptionSemantic("Function " + fnname + " is undefined.");
			// Save it for next time
			node.optimised = fndef;
		} else
			fndef = (FunctionDefinition)node.optimised;
		FunctionInvocation newInvocation = new FunctionInvocation(fndef);
		// Child 1 - arglist
		doChild(node, 1, newInvocation);
		// Execute
		scope.execute(newInvocation, this);
		return data;
	}
	
	// Function invocation in an expression
	public Object visit(ASTFnInvoke node, Object data) {
		FunctionDefinition fndef;
		if (node.optimised == null) { 
			// Child 0 - identifier (fn name)
			String fnname = getTokenOfChild(node, 0);
			fndef = scope.findFunction(fnname);
			if (fndef == null)
				throw new ExceptionSemantic("Function " + fnname + " is undefined.");
			if (!fndef.hasReturn())
				throw new ExceptionSemantic("Function " + fnname + " is being invoked in an expression but does not have a return value.");
			// Save it for next time
			node.optimised = fndef;
		} else
			fndef = (FunctionDefinition)node.optimised;
		FunctionInvocation newInvocation = new FunctionInvocation(fndef);
		// Child 1 - arglist
		doChild(node, 1, newInvocation);
		// Execute
		return scope.execute(newInvocation, this);
	}
	
	// Function invocation argument list.
	public Object visit(ASTArgList node, Object data) {
		FunctionInvocation newInvocation = (FunctionInvocation)data;
		for (int i=0; i<node.jjtGetNumChildren(); i++) {
			newInvocation.setArgument(doChild(node, i));
		}
		newInvocation.checkArgumentCount();
		
		return data;
	}
	
	// Execute an IF 
	public Object visit(ASTIfStatement node, Object data) {
		// evaluate boolean expression
		Value hopefullyValueBoolean = doChild(node, 0);
		if (!(hopefullyValueBoolean instanceof ValueBoolean))
			throw new ExceptionSemantic("The test expression of an if statement must be boolean.");
		if (((ValueBoolean)hopefullyValueBoolean).booleanValue())
			doChild(node, 1);							// if(true), therefore do 'if' statement
		else if (node.ifHasElse)						// does it have an else statement?
			doChild(node, 2);							// if(false), therefore do 'else' statement
		return data;
	}
	
	// Execute a FOR loop
	public Object visit(ASTForLoop node, Object data) {
		// loop initialisation
		doChild(node, 0);
		while (true) {
			// evaluate loop test
			Value hopefullyValueBoolean = doChild(node, 1);
			if (!(hopefullyValueBoolean instanceof ValueBoolean))
				throw new ExceptionSemantic("The test expression of a for loop must be boolean.");
			if (!((ValueBoolean)hopefullyValueBoolean).booleanValue())
				break;
			// do loop statement
			doChild(node, 3);
			// assign loop increment
			doChild(node, 2);
		}
		return data;
	}
	
	// Process an identifier
	// This doesn't do anything, but needs to be here because we need an ASTIdentifier node.
	public Object visit(ASTIdentifier node, Object data) {
		return data;
	}
	
	// Execute the WRITE statement
	public Object visit(ASTWrite node, Object data) {
		System.out.println(doChild(node, 0));
		return data;
	}
	
	// Dereference a variable or parameter, and return its value.
	public Object visit(ASTDereference node, Object data) {
		Display.Reference reference;
		DisplayClass.Reference classref;
		
		if (node.optimised == null) {
			String name = node.tokenValue;
			reference = scope.findReference(name);
			classref=scopeclass.findReference(name);
			//System.out.println(reference);
			if (reference == null && classref==null) 
			   
				   throw new ExceptionSemantic("Variable or parameter " + name + " is undefined.");
			if(classref!=null) {
				
				node.optimised=classref;
				}
			if(reference!=null) {
			
				node.optimised=reference;
			}
			
			}else {
					reference=(Display.Reference)node.optimised; 
					}
					
					return reference.getValue();
				}
	      
	
	
	// Execute an assignment statement.
	public Object visit(ASTAssignment node, Object data) {
		
		Display.Reference reference;
		if(node.optimised == null) {
			String name =getTokenOfChild(node,0);
			reference = scope.findReference(name);
			if(reference == null)  
				reference = scope.defineVariable(name);
			}else
				reference = (Display.Reference)node.optimised;
			reference.setValue(doChild(node,1));
			return data;
	}
	
	

	// OR
	public Object visit(ASTOr node, Object data) {
		return doChild(node, 0).or(doChild(node, 1));
	}

	// AND
	public Object visit(ASTAnd node, Object data) {
		return doChild(node, 0).and(doChild(node, 1));
	}

	// ==
	public Object visit(ASTCompEqual node, Object data) {
		return doChild(node, 0).eq(doChild(node, 1));
	}

	// !=
	public Object visit(ASTCompNequal node, Object data) {
		return doChild(node, 0).neq(doChild(node, 1));
	}

	// >=
	public Object visit(ASTCompGTE node, Object data) {
		return doChild(node, 0).gte(doChild(node, 1));
	}

	// <=
	public Object visit(ASTCompLTE node, Object data) {
		return doChild(node, 0).lte(doChild(node, 1));
	}

	// >
	public Object visit(ASTCompGT node, Object data) {
		return doChild(node, 0).gt(doChild(node, 1));
	}

	// <
	public Object visit(ASTCompLT node, Object data) {
		return doChild(node, 0).lt(doChild(node, 1));
	}

	// +
	public Object visit(ASTAdd node, Object data) {
		return doChild(node, 0).add(doChild(node, 1));
	}

	// -
	public Object visit(ASTSubtract node, Object data) {
		return doChild(node, 0).subtract(doChild(node, 1));
	}

	// *
	public Object visit(ASTTimes node, Object data) {
		return doChild(node, 0).mult(doChild(node, 1));
	}

	// /
	public Object visit(ASTDivide node, Object data) {
		return doChild(node, 0).div(doChild(node, 1));
	}

	// NOT
	public Object visit(ASTUnaryNot node, Object data) {
		return doChild(node, 0).not();
	}

	// + (unary)
	public Object visit(ASTUnaryPlus node, Object data) {
		return doChild(node, 0).unary_plus();
	}

	// - (unary)
	public Object visit(ASTUnaryMinus node, Object data) {
		return doChild(node, 0).unary_minus();
	}

	// Return string literal
	public Object visit(ASTCharacter node, Object data) {
		if (node.optimised == null)
			node.optimised = ValueString.stripDelimited(node.tokenValue);
		return node.optimised;
	}

	// Return integer literal
	public Object visit(ASTInteger node, Object data) {
		if (node.optimised == null)
			node.optimised = new ValueInteger(Long.parseLong(node.tokenValue));
		return node.optimised;
	}

	// Return floating point literal
	public Object visit(ASTRational node, Object data) {
		if (node.optimised == null)
			node.optimised = new ValueRational(Double.parseDouble(node.tokenValue));
		return node.optimised;
	}

	// Return true literal
	public Object visit(ASTTrue node, Object data) {
		if (node.optimised == null)
			node.optimised = new ValueBoolean(true);
		return node.optimised;
	}

	// Return false literal
	public Object visit(ASTFalse node, Object data) {
		if (node.optimised == null)
			node.optimised = new ValueBoolean(false);
		return node.optimised;
	}
	
   public Object visit(ASTQuit node, Object data) {
	   System.exit(0);
	   return data;
   }
   
   public Object visit(ASTWhile node,Object data) {
	   while(true) {
		   Value hopefullyValueBoolean = doChild(node, 0);
		   if (!(hopefullyValueBoolean instanceof ValueBoolean))
				throw new ExceptionSemantic("The test expression of a for loop must be boolean.");
			if (!((ValueBoolean)hopefullyValueBoolean).booleanValue())
				break;
			doChild(node, 1);   
	   }
	   return data;
	   
   }
   // define class
   public Object visit(ASTClassDef node, Object data) {
	    if(node.optimised != null)
		    return data;
		String classname = getTokenOfChild(node,0);
		//check if class name is already taken
		if(scopeclass.findClassInCurrentLevel(classname) !=null)
			throw new ExceptionSemantic("Function" + classname + "already exists.");
		//if name is not taken add to existing classes
		ClassDefinition currentclass = new ClassDefinition(classname,scopeclass.getLevel()+1);
		scopeclass.addClass(currentclass);
		//set class body
		currentclass.setClassBody(getChild(node,1));
		doChild(node,1,currentclass);
		node.optimised=currentclass;
		return data; 
   }
   
   public Object visit(ASTClassBody node, Object data) {
	    
		return doChildren(node,data);
		
   }
   
   //Class call
   public Object visit(ASTClassCall node, Object data) {

	        ClassDefinition classdef;
	        //gets token from user input
	        String classname=getTokenOfChild(node,0);
	        classdef=scopeclass.findClass(classname);
	   
	   if(classdef==null) {
		   throw new ExceptionSemantic ("Class " + classname + " is undefined.");
	   }
	   
	   node.optimised=classdef;
	   return data;
   }
   // Method Call
   public Object visit(ASTMethodCall node,Object data) {
	   
	   ClassDefinition classdef;
       FunctionDefinition fndef;
       //Child 0-class name
       String classname=getTokenOfChild(node,0);
       //Child 1-function name
       String fnname=getTokenOfChild(node,1);
       classdef=scopeclass.findClass(classname);
       
       //check if class exists
       if(classdef==null)
    	   throw new ExceptionSemantic("Class " + classname + "is undefined.");
       //check if function exists within the class	   
       fndef=classdef.findFunction(fnname);
       if(fndef==null)
    	   throw new ExceptionSemantic("Method "+fnname +" of Class " + classname + " is undefined.");
       //check if method has return 
       if (!fndef.hasReturn())
			throw new ExceptionSemantic("Function " + fnname + " is being invoked in an expression but does not have a return value.");
    
       node.optimised=fndef;   
      
	   FunctionInvocation newInvocation = new FunctionInvocation(fndef);
		   // Child 1 - arglist
	   //newInvocation.getLevel();
	   doChild(node, 2, newInvocation);
	   return scope.execute(newInvocation, this);
	
   }
   
   //Attribute call
   public Object visit(ASTClassAssignment node, Object data) {
	   	
	   if(node.optimised != null)
		    return data;
	    //Child 0- object name
		String currentclass = getTokenOfChild(node,0);
		//Child 1- class name 
		String calledclass  =  getTokenOfChild(node,1);
		//Check if there is any objects from the called class with the same name
		if(scopeclass.findClassInCurrentLevel(currentclass) !=null)
			throw new ExceptionSemantic("Function" + currentclass + "already exists.");
		ClassDefinition classdef = new ClassDefinition(currentclass,scopeclass.getLevel()+1);
		ClassDefinition temp;
		temp=scopeclass.findClass(calledclass);
		//Set object body
		classdef.setClassBody(temp.getClassBody());
		ClassInvocation invo = new  ClassInvocation(classdef);		
		doChildren(classdef.getClassBody(),invo);
		
		node.optimised=currentclass;
			return data;
	}
   //Attribute call
   public Object visit(ASTAttributeCall node,Object data) {

	   ClassDefinition classdef;
       Display.Reference ref;
       //get tokenns from user input
       String classname=getTokenOfChild(node,0);
       String attriname=getTokenOfChild(node,1);
       classdef=scopeclass.findClass(classname);
      //check if class exists
       if(classdef==null)
    	   throw new ExceptionSemantic("Class " + classname + "is undefined.");
    	//find attribute within the class 
       ref=scope.findReference(attriname);
       
	   return ref.getValue();
	   
   }
   
   public Object visit(ASTSwitchCase node, Object data) {
		Value sName = doChild(node,0);
		doChild(node, 1, sName);
		return data;
}

//Execute Case Body
public Object visit(ASTCaseBody node, Object data)
{
	boolean defCheck = true;
	Value sName = (Value)data;
	String sNameTemp= "" + sName;
	for (int i=0; i<node.jjtGetNumChildren()-1; i=i+2)
	{
		Value cName = doChild(node, i);
		String cNameTemp = "" + cName;
		if(sNameTemp.contains(cNameTemp))
		{
			defCheck = false;
			doChild(node, i+1);	
		}
	}
	if(defCheck)	
		doChild(node, node.jjtGetNumChildren()-1);
	return data;
}

//Execute Default Case
public Object visit(ASTDefaultCase node, Object data)
{ 
	doChild(node, 0);
	return data;
}

public Object visit(ASTArrayDef node, Object data){
    if(node.optimised != null)
    	return data;
    String arrayname = getTokenOfChild(node,0);
    ArrayDefinition arraydef = new ArrayDefinition(arrayname,scope.getLevel()+1);
    ArrayInvocation newInvocation = new ArrayInvocation(arraydef);
    doChild(node,1,newInvocation);
	scopearray.addArray(arraydef);
	return data;
}
// set value of each index within an array 
public Object visit(ASTArray node,Object data) {
	 ArrayInvocation array = (ArrayInvocation)data;
		for (int i=0; i<node.jjtGetNumChildren(); i++) {
			array.setValue(i, doChild(node,i));
		}
	
		
	return data;
}
//get the value at specied index in a array
public Object visit(ASTGetElement node,Object data) {
	
	ArrayDefinition arraydef;
    String arrayname=getTokenOfChild(node,0);
    String index=getTokenOfChild(node,1);
    arraydef=scopearray.findArray(arrayname);
    ArrayInvocation x = new ArrayInvocation(arraydef);
	return x.getValue(Integer.parseInt(index));
}

// Execute a Fibonacci sequence
public Object visit(ASTFibonacciSequence node, Object data) {
	Value count = doChild(node, 0);
	int n1 = 0;
	int n2 = 1;
	int n3;
	System.out.println(n1);
	System.out.println(n2);
	for(int i=2; i<count.longValue(); i++)
	{
		n3 = n1 + n2;
		n1 = n2;
		n2 = n3;
		System.out.println(n3);
	}
	return data;
}
   
 
   
}
