package uk.ac.derby.ldi.sili2.interpreter;

import java.util.HashMap;
import java.util.Vector;

import uk.ac.derby.ldi.sili2.parser.ast.SimpleNode;

public class ArrayDefinition {
	
	private String name;
	private HashMap<String, Integer> slots = new HashMap<String, Integer>();
	private HashMap<String ,ArrayDefinition> arrays = new HashMap<String ,ArrayDefinition>();
	//private Vector<Integer> slots = new Vector<Integer>();
	private int depth;
	private SimpleNode ASTArray = null;
	ArrayDefinition(String ArrayName, int level) {
		name = ArrayName;
		depth = level;
	}
	
	/** Get the depth of this definition.
	 * 0 - root or main scope
	 * 1 - definition inside root or main scope
	 * 2 - definition inside 1
	 * n - etc.
	 */
	int getLevel() {
		System.out.println(slots);
		return depth;
	}
	
	/** Get the name of this function. */
	String getName() {
		return name;
	}
	
	/** Set the function body of this function. */
	void setArray(SimpleNode node) {
		ASTArray = node;
	}
	
	/** Get the function body of this function. */
	SimpleNode getArray() {
	    //System.out.println("function name:"+this.getName());
	    //System.out.println("function variables:"+this.slots);
	    //System.out.println("functionbody:"+this.ASTFunctionBody);
		return this.ASTArray;
	}
	
	/** Set the return expression of this function. */
	/*void setFunctionReturnExpression(SimpleNode node) {
		ASTFunctionReturnExpression = node;
	}
	
	/** Get the return expression of this function. 
	SimpleNode getFunctionReturnExpression() {
		return ASTFunctionReturnExpression;
	}
	*/
	/** Get the signature of this function. */

	
	/** Get the storage slot number of a given variable or parm.  Return -1 if it doesn't exist. */

	
	/** Define a variable.  Return its slot number. */
	int defineVariable(String name) {
		Integer slot = slots.get(name);
		if (slot != null)
			return slot.intValue();
		int slotNumber = slots.size();
		slots.put(name, Integer.valueOf(slotNumber));
		return slotNumber;
	}	
	
	/** Add an inner function definition. */
	void addArray(ArrayDefinition definition) {
		arrays.put(definition.getName(), definition);
	}
	void addElement(String name) {
		 
			 Integer v=Integer.parseInt(name);
			 
			 slots.put(name, v);
			 //System.out.println(slots);
		//slots.put(key, value)
	}
	
	/*void addArray(ArrayDefinition definition) {
		arrays.put(definition.getName(), definition);
	}*/
	
	Integer getLocalSlotNumber(String name) {
		 Integer slot = slots.get(name);
		 //System.out.println(slot);
		if (slot == null)
			return null;
		 //String temp;
		//=slot.toString();
		return slot;
	}
	
	int getLocalCount() {
		return slots.size();
	}
	
	/** Find an inner function definition.  Return null if it doesn't exist. */
	Integer findVarable(String name) {
		return slots.get(name);
	}
	
	ArrayDefinition findArray(String name) {
		return arrays.get(name);
	}

}
