package uk.ac.derby.ldi.sili2.interpreter;

import uk.ac.derby.ldi.sili2.interpreter.Display.Reference;
import uk.ac.derby.ldi.sili2.values.Value;

public class DisplayArray {
	private final int maximumArrayNesting = 64;
	private ArrayInvocation[] display = new ArrayInvocation[maximumArrayNesting];
	private int currentLevel;

	/** Reference to a slot. */
	class Reference {
		private int displayDepth;
		private int slotNumber;
		
		/** Ctor */
		Reference(int depth, int slot) {
			displayDepth = depth;
			slotNumber = slot;
		}
		
		/** Set value pointed to by this reference. */
		void setValue(Value v) {
			display[displayDepth].setValue(slotNumber, v);
		}
		
		/** Get value pointed to by this reference. */
		Value getValue() {
		
			return display[displayDepth].getValue(slotNumber);
		}
	}
	
	/** Ctor */
	DisplayArray() {
		// root or 0th scope
		currentLevel = 0;
		display[currentLevel] = new ArrayInvocation(new ArrayDefinition("%main", currentLevel));
	}
	
	/** Execute a Array in its scope, using a specified parser. */
	/*Value execute(ArrayInvocation fn, Parser p) {
		int changeLevel = fn.getLevel();
		ArrayInvocation oldContext = display[changeLevel];
		int oldLevel = currentLevel;
		display[changeLevel] = fn;
		currentLevel = changeLevel;
		Value v = display[currentLevel].execute(p);
		display[changeLevel] = oldContext;
		currentLevel = oldLevel;
		return v;
	}*/
	
	/** Get the current scope nesting level. */
	int getLevel() {
		return currentLevel;
	}
	
	/** Return a Reference to a variable or parameter.  Return null if it doesn't exist. */
	Reference findReference(String name) {
		int level = currentLevel;
		while (level >= 0) {
			int offset = display[level].findSlotNumber(name);
			if (offset >= 0)
				return new Reference(level, offset);
			level--;
		}
		return null;		
	}

	/** Create a variable in the current level and return its Reference. */
	Reference defineVariable(String name) {
		return new Reference(currentLevel, display[currentLevel].defineVariable(name));
	}

	/** Find a Array.  Return null if it doesn't exist. */
	ArrayDefinition findArray(String name) {
		int level = currentLevel;
		while (level >= 0) {
			ArrayDefinition definition = display[level].findArray(name);
			if (definition != null)
				return definition;
			level--;
		}
		return null;
	}
	
	/*ArrayDefinition findArray(String name) {
		int level= currentLevel;
		while(level>=0) {
			ArrayDefinition definition = display[level].findArray(name);
			if(definition!=null)
				return definition;
			level--;
		}
		return null;
	}
	
	ArrayDefinition findArrayLowerLevel(String name) {
		int level=currentLevel;
		ArrayDefinition definition = display[level-1].findArray(name);
		if(definition !=null)
			return definition;
		return null;
	}

	/** Find a Array in the current level.  Return null if it doesn't exist. */
	ArrayDefinition findArrayInCurrentLevel(String name) {
		return display[currentLevel].findArray(name);
	}
	
	/** Add a Array to the current level. */
	void addArray(ArrayDefinition definition) {
		display[currentLevel].addArray(definition);
	}
	

	

}
