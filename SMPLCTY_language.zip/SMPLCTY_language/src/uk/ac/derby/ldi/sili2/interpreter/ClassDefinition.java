package uk.ac.derby.ldi.sili2.interpreter;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Vector;

import uk.ac.derby.ldi.sili2.parser.ast.SimpleNode;

public class ClassDefinition implements Comparable<Object>,Serializable {
	/*private static final long serialVersionUID = 0;
	
	private String name;
	private HashMap<String, Integer> ints = new HashMap<String, Integer>();
	private HashMap<String, Boolean> bools =new HashMap<String, Boolean>();
	private HashMap<String, String> str =new HashMap<String, String>();

	private HashMap<String, FunctionDefinition> functions = new HashMap<String, FunctionDefinition>();
	private SimpleNode ASTClassBody = null;
	private SimpleNode ASTClassBody = null;
	private int depth;
	*/
	private static final long serialVersionUID = 0;
    
	private String name;
	private String parmSignature = "";
	private Vector<String> parameters = new Vector<String>();
	//private HashMap<String,arraylist<Integer>> attributes = new Vector<String>();
	private HashMap<String, Integer> slots = new HashMap<String, Integer>();
	//private HashMap<String, String> strings = new HashMap<String, String>(); 
	private HashMap<String, FunctionDefinition> functions = new HashMap<String, FunctionDefinition>();
	private HashMap<String, ClassDefinition> classes = new HashMap<String, ClassDefinition>();
	//private HashMap<String ,ArrayDefinition> arrays = new HashMap<String ,ArrayDefinition>();
	private SimpleNode ASTClassBody = null;
	private SimpleNode ASTClassReturnExpression = null;
	private int depth;
	
	/** Ctor for Class definition. */
	ClassDefinition(String ClassName, int level) {
		name = ClassName;
		depth = level;
	}
	
	/** Get the depth of this definition.
	 * 0 - root or main scope
	 * 1 - definition inside root or main scope
	 * 2 - definition inside 1
	 * n - etc.
	 */
	int getLevel() {
		//System.out.println("slots: "+slots);
		return depth;
	}
	
	/** Get the name of this Class. */
	String getName() {
		//System.out.println(classes);
		return name;
	}
	
	/** Set the Class body of this Class. */
	void setClassBody(SimpleNode node) {
		//System.out.println(functions);
		ASTClassBody = node;
		//System.out.println(ASTClassBody);
	}
	
	/** Get the function body of this function. */
	SimpleNode getClassBody() {
		return ASTClassBody;
	}
	
	
	/** Get the signature of this function. */
	String getSignature() {
		return (hasReturn() ? "value " : "") + getName() + "(" + parmSignature + ")";
	}
	
	/** True if this Class has a return value. */
	boolean hasReturn() {
		return (ASTClassReturnExpression != null);
	}
	
	/** Comparison operator.  Functions of the same name are the same. */
	public int compareTo(Object o) {
		return name.compareTo(((ClassDefinition)o).name);
	}
	
	/** Get count of parameters. */
	int getParameterCount() {
		return parameters.size();
	}
	
	/** Get the name of the ith parameter. */
	String getParameterName(int i) {
		return parameters.get(i);
	}
	
	/** Define a parameter. */
	void defineParameter(String name) {
		if (parameters.contains(name))
			throw new ExceptionSemantic("Parameter " + name + " already exists in function " + getName());
		parameters.add(name);
		parmSignature += ((parmSignature.length()==0) ? name : (", " + name));
		defineVariable(name);
	}
	
	/** Get count of local variables and parameters. */
	int getLocalCount() {
		return slots.size();
	}
	
	
	/** Get the storage slot number of a given variable or parm.  Return -1 if it doesn't exist. */
	int getLocalSlotNumber(String name) {
		Integer slot = slots.get(name);
		if (slot == null)
			return -1;
		return slot.intValue();
	}
	
	/** Define a variable.  Return its slot number. */
	int defineVariable(String name) {
		Integer slot = slots.get(name);
		System.out.println(slots);
		if (slot != null)
			return slot.intValue();
		int slotNumber = slots.size();
		slots.put(name, Integer.valueOf(slotNumber));
		return slotNumber;
	}	
	
	
	/** Add an inner function definition. */
	void addFunction(FunctionDefinition definition) {
		functions.put(definition.getName(), definition);
		//System.out.println("class functions: "+functions);
	}
	
	void addClass(ClassDefinition definition) {
		classes.put(definition.getName(), definition);
		//System.out.println(classes);
	}
	/*void addArray(ArrayDefinition definition) {
		arrays.put(definition.getName(), definition);
	}*/
	
	/** Find an inner function definition.  Return null if it doesn't exist. */
	ClassDefinition findClass(String name) {
		//System.out.println(functions);
		return classes.get(name);
	}
	
	FunctionDefinition findFunction(String name) {
		//System.out.println("class functions: "+functions);
		return functions.get(name); 
	}
	
	void constructor(FunctionInvocation definition) {
		
			System.out.println("con:"+definition.getValue(0));
	}
	Integer findVariable(String name) {
		System.out.println(slots);
		return slots.get(name);
	}


}