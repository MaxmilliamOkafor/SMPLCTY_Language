package uk.ac.derby.ldi.sili2.interpreter;

import java.util.Vector;

import uk.ac.derby.ldi.sili2.values.Value;

public class ArrayInvocation {

	private ArrayDefinition Array;
	private int argumentCount = 0;
	private Vector<Value> slots;
	
	private final void setSlot(int n, Value v) {
		if (n >= slots.size())
			slots.setSize(n + 1);
		slots.set(n, v);
	}
	
	/** Ctor for user-defined Array. */
	ArrayInvocation(ArrayDefinition fndef) {
		Array = fndef;
		
		slots = new Vector<Value>(Array.getLocalCount());
	}
	
	/** Get the level of the associated Array. */
	int getLevel() {
		System.out.println(slots);
		return Array.getLevel();
	}
	

	


	/** Get the slot number of a given variable or parameter name.  Return -1 if not found. */
	int findSlotNumber(String name) {
		return Array.getLocalSlotNumber(name);
	}
	
	/** Get a variable or parameter value given a slot number. */
	Value getValue(int slotNumber) {
		System.out.println(slots);
		return slots.get(slotNumber);
	}

	/** Given a slot number, set its value. */
	void setValue(int slotNumber, Value value) {
		setSlot(slotNumber, value);
	}

	/** Define a variable in the Array definition.  Return its slot number. */
	int defineVariable(String name) {
		return Array.defineVariable(name);
	}
	
	/** Add a Array definition. */
	void addArray(ArrayDefinition definition) {
		Array.addArray(definition);
	}
	
	
	/** Find a Array definition.  Return null if it doesn't exist. */
	ArrayDefinition findArray(String name) {
		return Array.findArray(name);
	}
	
	
}
