/** Convenient runner for the Sili interpreter. */

public class Sili {
	public static void main(String[] args) {
		uk.ac.derby.ldi.sili2.interpreter.Interpreter.main(args);
	}
}
