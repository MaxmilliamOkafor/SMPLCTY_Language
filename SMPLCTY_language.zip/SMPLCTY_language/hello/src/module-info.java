module hello {
}